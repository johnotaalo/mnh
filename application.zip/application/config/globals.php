<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

/*Tables*/
$config['project_url'] ='http://'.$_SERVER['SERVER_NAME'].'/program-monitor';
